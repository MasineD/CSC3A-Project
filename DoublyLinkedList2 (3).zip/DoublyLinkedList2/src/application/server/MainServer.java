package application.server;


//import java.io.BufferedReader;
import java.io.IOException;
//import java.io.InputStreamReader;
//import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
/*
 * @author Jm Molomo
 */
public class MainServer{
	
	
	private int Port = 1450;
	//Create the Client & Server Socket
	
	private ServerSocket sSocket; //Server Socket
	
	public MainServer() {
		//Open Connection
		try {
			sSocket = new ServerSocket(Port);
			
			connectClient();	
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
public void connectClient() {
	
		//keep connection alive
	System.out.println("Starting...");
	while(true) {
		try {
			//accept connection
			Socket cClient =  sSocket.accept();
			 
				//create Thread
				ClientHandler cH = new ClientHandler(cClient);
				Thread SClient = new Thread(cH);
			     SClient.start();
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
}

//downloading a processed image

public static void main(String[] args) {	
//	MainServer is = 
	new MainServer();	
	
  
}

}