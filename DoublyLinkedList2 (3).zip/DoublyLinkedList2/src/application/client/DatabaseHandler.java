package application.client;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

/*import application.client.Heap;
import application.client.HeapNode;
import javafx.application.Application;*/
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
/*import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;*/
import javafx.stage.Stage;

public class DatabaseHandler {
     
	   private static final int NODE_RADIUS = 20;
	    private static final int LEVEL_SPACING = 80;
	    private Heap heap;
	    @SuppressWarnings("unused")
		private PaneController paneController;
	
	private Pane panee;
	 
	public DatabaseHandler(PaneController paneControl)
	{    
        TextArea consoleOutput = new TextArea();
		consoleOutput.setEditable(false);
		consoleOutput.setWrapText(true);
		consoleOutput.setPrefSize(800, 300);
		
		// Redirect System.out to the TextArea
		PrintStream consoleStream = new PrintStream(new OutputStream() {
		    @Override
		    public void write(int b) throws IOException {
		        Platform.runLater(() -> consoleOutput.appendText(String.valueOf((char)b)));
		    }
		});
		System.setOut(consoleStream);
		
		this.paneController = paneControl;	
		panee = new Pane();
		panee.setPrefSize(662, 422);
        heap = new Heap();
        heap.readFile("data/Treatments.txt", heap.details, heap.heap); // Load heap data

        Canvas canvas = new Canvas(800, 422);
        GraphicsContext gc = canvas.getGraphicsContext2D();

        if (!heap.isEmpty()) 
        {
//        	System.out.println("Heap is not empty");
            drawHeap(gc, 0, canvas.getWidth() / 2, NODE_RADIUS * 2, canvas.getWidth() / 4);
        }
        
        Stage heapStage = new Stage();
              
        Pane cPane = new Pane();
        
        Pane tPane = new Pane();
        tPane.setLayoutY(300);
        tPane.setPrefSize(800, 422);
        
        tPane.getChildren().addAll(consoleOutput);
        cPane.getChildren().addAll(canvas);
        panee.getChildren().addAll(cPane, tPane);	

        Scene scene = new Scene(panee, 800, 600);
        heapStage.setTitle("Recommended Treatments");
        heapStage.setScene(scene);
        heapStage.show();
		         
        System.out.println("*********************************************");
        System.out.println("     Heap implementation with arrayList:     ");
        System.out.println("*********************************************\n");
        heap.display(heap.heap);
        
        //reading the key from a Text file
        int targetKey = readText("data/server/Info.txt");;
        List<Integer> foundIndices = heap.aStarSearchRange(heap.heap, targetKey);
        if (!foundIndices.isEmpty()) 
        {
            if(contact.toUpperCase().equals("YES")) {
            	System.out.println("\nRecommended treatment for age " + age +" with \'"+ symptom +"\' symptoms, "
            + "had contact with infected person, and " + targetKey + "% similarity is:");
            }
            else if(contact.toUpperCase().equals("NO")) {
            	System.out.println("\nRecommended treatment for age " + age +" with \'"+ symptom +"\' symptoms, "
                        + "had no contact with infected person, and " + targetKey + "% similarity is:");
            }
            for (int index : foundIndices) 
            {
                HeapNode node = heap.heap.get(index);
                System.out.println(node.values[0]);
            }
        } else {
            System.out.println("\nNo keys found within ±5 of " + targetKey);
        }
        /*
        heap.deleteNode(heap.heap, 67);
        System.out.println("\n*********************************************");
        System.out.println("         After deleting a key element        ");
        System.out.println("*********************************************\n");
        heap.display(heap.heap);
       readText("data/server/Info.txt");*/
       
       Runtime.getRuntime().addShutdownHook(new Thread(() -> {
           System.setOut(System.out);
       }));
	}

	private void drawHeap(GraphicsContext gc, int index, double x, double y, double xOffset) 
	{
		if (index >= heap.size()) return;

		HeapNode node = heap.heap.get(index);

		gc.setStroke(Color.BLACK);
		gc.setLineWidth(2);

		// Draw white-filled circle with black border
		gc.setFill(Color.WHITE);
		gc.fillOval(x - NODE_RADIUS, y - NODE_RADIUS, NODE_RADIUS * 2, NODE_RADIUS * 2);
		gc.strokeOval(x - NODE_RADIUS, y - NODE_RADIUS, NODE_RADIUS * 2, NODE_RADIUS * 2);

		// Draw node value
		gc.setFill(Color.BLACK);
		gc.strokeText(String.valueOf(node.getKey()), x - 5, y + 5);

		int leftIndex = heap.leftChild(index);
		int rightIndex = heap.rightChild(index);

		if (heap.hasLeft(index)) 
		{
			double leftX = x - xOffset;
			double leftY = y + LEVEL_SPACING;

			double angle = Math.atan2(leftY - y, leftX - x);
			double startX = x + NODE_RADIUS * Math.cos(angle);
			double startY = y + NODE_RADIUS * Math.sin(angle);
			double endX = leftX - NODE_RADIUS * Math.cos(angle);
			double endY = leftY - NODE_RADIUS * Math.sin(angle);

			gc.strokeLine(startX, startY, endX, endY);
			drawHeap(gc, leftIndex, leftX, leftY, xOffset / 2);
		}

		if (heap.hasRight(index)) 
		{
			double rightX = x + xOffset;
			double rightY = y + LEVEL_SPACING;

			double angle = Math.atan2(rightY - y, rightX - x);
			double startX = x + NODE_RADIUS * Math.cos(angle);
			double startY = y + NODE_RADIUS * Math.sin(angle);
			double endX = rightX - NODE_RADIUS * Math.cos(angle);
			double endY = rightY - NODE_RADIUS * Math.sin(angle);

			gc.strokeLine(startX, startY, endX, endY);
			drawHeap(gc, rightIndex, rightX, rightY, xOffset / 2);
		}
	}
	
	//Variables used in the readText method
	String name, age, symptom, contact, result;
	public int readText(String path) {
		int percent = 0;
		    	
		File f = new File(path);
		try 
		{
		    		
			Scanner sc = new Scanner(f);
			while(sc.hasNext())
			{
				String line = sc.nextLine();
				StringTokenizer tokenizer = new StringTokenizer(line, " ");
				name = tokenizer.nextToken();
				age = tokenizer.nextToken();
				symptom = tokenizer.nextToken();
				contact = tokenizer.nextToken();
						
				result = tokenizer.nextToken();
				percent = (int) Double.parseDouble(result); 
			}
			sc.close();
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}
		    	
		return percent;
	}
	
	public Pane returnpane()
	{
		return panee;
	}
	
}
