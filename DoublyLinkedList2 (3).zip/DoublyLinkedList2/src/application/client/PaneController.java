package application.client;

/*import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.StringTokenizer;*/

import javafx.scene.layout.Pane;

public class PaneController {
    private Pane mainPane;
    private MedClient medClient;
    private Diagnose diagnose;
    private DatabaseHandler databaseHandler;
    
    public PaneController() {
		mainPane = new Pane();
		medClient = new MedClient(this);
		diagnose = new Diagnose(this);
		
		// Set the initial pane to MedClient
		mainPane.getChildren().add(medClient.getPane());
	}
    
    public void switchToDatabase() {
    			mainPane.getChildren().clear();
			      mainPane.getChildren().add(databaseHandler.returnpane());
    }
    
    public void switchToDiagnose() {
    			mainPane.getChildren().clear();
    		      mainPane.getChildren().add(diagnose.getPane());
    }
    
    public void switchToMedClient() {
				mainPane.getChildren().clear();
			      mainPane.getChildren().add(medClient.getPane());
	}
    

    
    public Pane getPane() {
		return mainPane;
	}
}
