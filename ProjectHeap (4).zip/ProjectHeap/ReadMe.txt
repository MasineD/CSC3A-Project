=======Part One=======


<------Project Achitecture------>

1. Project Structure
 
 -> Has Two Packages 
    Application
    1)This has Main.Java
    Application.Client (This Stores the Layout of the Client)
    1.MedClient.Java 
    -> This returns the Client Layout
   (Returns a pane which is instantiated in the Main.java)
   -> Button start directs to
   2.Diagnose.java
   -> This handles the actual functionality of the client
   1) Enter Patient Details
   2) Enter Symptoms
   3) Enter Diagnosis
   4) Upload Xray to Image Viewe
   
   5) A button to send the data to the server
    Main Functions
    1) Uploads intakes Name of the Patient
    2) When clicking diagnose button it will clear pane and Download the latest everything from Server
    Application.Server
    
    1) This has Two Class
     a) MainServer -> This is what keeps the Server running (Uses multithreading so it doesnt disturb the actual flow)
     b) ClientHandler -> This handles the client requests
      Which has the Following methods
      1) Uploads -> When user Uploads an Image this is what handles the image and saves it to the server
      2) GreyScale -> The image is converted to greyscale and saved to the server
      3) Blur -> The image is blurred and saved to the server
      4) We use Sobel Filter to detect the edges of the image and save it to the server
      5) We split the image into 3by3 for training
      5) We use this Sobel to train our KNN model
      6) KNN converts the image into edges
      7) We fetch all the pixels in the KNN
      8) we use isbool to check if its a node or not
      9) we store the nodes inside a list
      10) we trace between the nodes
      11) we plot the nodes
      
      
      
      