//import java.util.ArrayList;
package application.client;

public class HeapNode 
{
	int key;
    String[] values;

    HeapNode(int key) 
    {
        this.key = key;
        this.values = new String[100]; // = new ArrayList<>();
    }

    void addValue(int key, String value) 
    {
    	/*for(int i = 0;i < values.length; i++)
    	{
    		if( i == key) {
    			values[i] = value;
    		}
    	}
		  values.add(value);
		  values.*/
    	values[0] = value;
    }
    public int getKey()
    {
    	return key;
    }
    public String[] getValues()
    {
    	return values;
    }
}
