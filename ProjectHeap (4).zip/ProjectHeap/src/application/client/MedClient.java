package application.client;

import javafx.scene.control.Button;
import javafx.scene.control.Separator;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

public class MedClient {

    Pane pane = new Pane();
    Diagnose diagnose = new Diagnose();
    
    /**
	 * Constructor to create the MedClient GUI.
	 * This constructor initializes the GUI components and sets up the layout.
	 */
    public MedClient() {
        pane = new Pane();
        pane.setPrefSize(662, 422);
        RenderPane();
    }

    public void RenderPane() {
        Separator topSeparator = new Separator();
        topSeparator.setLayoutY(44);
        topSeparator.setPrefSize(662, 6);

        Rectangle header = new Rectangle(662, 43);
        header.setArcWidth(5);
        header.setArcHeight(5);
        header.setFill(Color.web("#ff1f43"));
        header.setStroke(Color.BLACK);

        Text titleText = new Text(46, 26, "Medical App");
        titleText.setFill(Color.web("#e1d8d8"));
        titleText.setFontSmoothingType(javafx.scene.text.FontSmoothingType.LCD);
        titleText.setFont(Font.font("Arial Bold Italic", 16));
        
        
        Image logoImage = new Image("assets/Logo.png");
        ImageView logo = new ImageView(logoImage);
        logo.setLayoutX(14);
        logo.setLayoutY(7);
        logo.setFitHeight(33);
        logo.setFitWidth(32);
        logo.setPreserveRatio(true);
        
        Button homeButton = createButton("Home", 274, 7, 57, 29);
        Button diagnoseButton = createButton("Diagnose", 352, 7, 96, 29);
        Button databaseButton = createButton("DataBase", 457, 7, 82, 29);
        Button logoutButton = createButton("Log Out", 569, 6, 82, 29);
        
        Image logoImage2 = new Image("assets/Screenshot 2025-04-14 230131.png");
        ImageView banner = new ImageView(logoImage2);
        banner.setLayoutY(43);
        banner.setFitHeight(330);
        banner.setFitWidth(662);
        banner.setPreserveRatio(true);

        Text welcomeText = new Text(46, 92, "Welcome to,");
        welcomeText.setFill(Color.web("#cc1313"));
        welcomeText.setFontSmoothingType(javafx.scene.text.FontSmoothingType.LCD);
        welcomeText.setFont(Font.font("Arial Black", 19));

        Text appName = new Text(48, 119, " Medical App");
        appName.setFill(Color.web("#5b3232"));
        appName.setFont(Font.font("System Bold Italic", 18));

        Text description = new Text(47, 164, "Our innovative medical app leverages advanced machine learning algorithms, including K-Nearest Neighbors (K-NN), to assist in the early detection of COVID-19 from chest X-ray scans. Designed with accuracy and efficiency in mind, the app analyzes radiographic images using a comprehensive diagnostic model trained on a diverse dataset.");
        description.setFill(Color.web("#793232"));
        description.setFont(Font.font("Consolas Bold Italic", 13));
        description.setWrappingWidth(454);

        Button startNowButton = createButton("Start Now", 48, 260, 113, 25);
        startNowButton.setOnAction(e -> {
            pane.getChildren().clear();
            pane.getChildren().add(diagnose.getPane());
        });
        
        Separator bottomSeparator = new Separator();
        bottomSeparator.setLayoutX(4);
        bottomSeparator.setLayoutY(375);
        bottomSeparator.setPrefSize(654, 6);

        Text footer = new Text(233, 403, "Developed by the @A-Team");
        footer.setFont(Font.font("Arial Black", 10));

        // Add all elements to pane
        pane.getChildren().addAll(
                topSeparator, header, titleText, logo,
                homeButton, diagnoseButton, databaseButton, logoutButton,
                banner, welcomeText, appName, description,
                startNowButton, bottomSeparator, footer
        );
    }

    private Button createButton(String text, double x, double y, double width, double height) {
        Button button = new Button(text);
        button.setLayoutX(x);
        button.setLayoutY(y);
        button.setPrefSize(width, height);
        button.setStyle("-fx-background-color: #ff1f43;");
        button.setTextFill(Color.web("#f7f4f4"));
        button.setFont(Font.font("Arial Italic", 13));
        return button;
    }

    public  Pane getPane() {
        return pane;
    }
}

