package application.client;

public class Entry 
{
    int index;
    int cost;
    int heuristic;

    public Entry(int index, int cost, int heuristic) 
    {
        this.index = index;
        this.cost = cost;
        this.heuristic = heuristic;
    }
}
