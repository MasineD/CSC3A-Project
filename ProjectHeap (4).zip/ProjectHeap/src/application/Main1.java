package application;

import application.client.MedClient;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;

/**
 * @author JM Molomo
 * @author Amanda
 */

public class Main1 extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			MedClient medClient = new MedClient();
			
			Scene scene = new Scene(medClient.getPane(), 662, 422);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
